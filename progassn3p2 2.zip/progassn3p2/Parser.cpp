#include "Parser.h"

using namespace std;

/* initialize constants here */

const char * Parser::delimeters = "+-*/^() ";
const char Parser::opTable[] = {'\0','$','(',')','^','*','/','+','-','~'};


const Parser::Precedence Parser::precTable[] = {
    Precedence(0,-1),   // END
    Precedence(0,0),    // VALUE
    Precedence(100,0),  // LPAREN
    Precedence(0,99),   // RPAREN
    Precedence(6,5),    // EXP
    Precedence(3,4),    // MULT
    Precedence(3,4),    // DIV
    Precedence(1,2),    // PLUS
    Precedence(1,2),    // MINUS
    Precedence(8,7)     // UNARY MINUS
};

/* describe rest of functions */

Parser::EnumTokens Parser::getToken(string c, EnumTokens prevToken)
{
    if (c == "\0")          return END;
    if (c == "^")           return EXP;
    else if (c == "/")      return DIV;
    else if (c == "*")      return MULT;
    else if (c == "(")      return LPAREN;
    else if (c == ")")      return RPAREN;
    else if (c == "+")      return PLUS;
    else if (c == "~")      return UNARY_MINUS;
    else if (c == "-") 
    {
        if (prevToken == VALUE || prevToken == RPAREN) return MINUS;
        else return UNARY_MINUS;
    }
    
    curVal = c; // token is var or number
    
    return VALUE;
}

void Parser::printPostfix()
{
    LinkedQueue<string> newpost;
    string item = "";
    
    while (!postfix.isEmpty())
    {
        item = (postfix.dequeue());
        newpost.enqueue(item);
        cout << item << " "; // separate so different multi-digit numbers are identifiable
    }
    
    cout << endl;
    postfix = newpost;
}

void Parser::toPostfix(bool trace) // returns false if there is a problem
{
    int op;
    string c;
    
    EnumTokens newToken = END;
    
    int tokenIndex = 0;
    
    do {
        c = tokens[tokenIndex++];
        
        while (c == " ") c = tokens[tokenIndex++];  // iterate if just whitedspace
        newToken = getToken(c, newToken);   // get a new token
        
        switch (newToken)
        {
            case VALUE: // if its a value
            {
                postfix.enqueue(curVal);
                break;
            }
                
            case RPAREN: // if its a right parenthese
            {
                op = opStack.top();
                
                // enqueue until lparen
                while (op != LPAREN)
                {
                    postfix.enqueue(string(1, opTable[op]));
                    opStack.pop();
                    op = opStack.top();
                }
                
                opStack.pop(); // remove lparen
                break;
            }
                
            case END: // if its at the end
            {
                // pop the rest
                while (!opStack.isEmpty())
                {
                    op = opStack.top();
                    if (op != END) postfix.enqueue(string(1, opTable[op]));
                    opStack.pop();
                }
                break;
            }
                
            case LPAREN: // if its a left parenthese
            {
                // push that new token
                opStack.push(newToken); 
                break;
            }
                
            case EXP: 
            case DIV: 
            case MULT: 
            case PLUS: 
            case MINUS: 
            case UNARY_MINUS: // if its an operator of some sort
            {
                op = opStack.top();
                
                // compare using the prectable
                while (precTable[newToken].input <= precTable[op].stack)
                {
                    postfix.enqueue(string(1, opTable[op]));
                    opStack.pop();
                    op = opStack.top();
                }
                
                opStack.push(newToken); 
                break;
            }
    
            default: // error!
            {
                cerr << "Invalid token!" << endl;
            }
        }
    
        if (trace)
        {
            cout << "\topStack: " << opStack << endl;
            cout << "\tpostfix: " << postfix << endl;
        }
    
    } while (newToken != END);
}

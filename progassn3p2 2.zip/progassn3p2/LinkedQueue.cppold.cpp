//LinkedQueue.cpp

#include "LinkedQueue.h"

// assignment operator

template <typename T>
LinkedQueue<T>& LinkedQueue<T>::operator=(const LinkedQueue<T>& queue)
{
    ll.removeAll();
    ll = queue.ll;
    return *this;
}

// accessor function

template <typename T>
T LinkedQueue<T>::first( ) const throw(QueueEmptyException)
{ 
    if (ll.isEmpty())
    {
        throw QueueEmptyException();
    }
    else
    {
        return ll.getHead()->getElem();
    }
}

// update functions

template <typename T>
T LinkedQueue<T>::dequeue( ) throw(QueueEmptyException)
{
    if (ll.isEmpty())
    {
        throw QueueEmptyException();
    }
    else
    {
        return ll.removeFirst();
    }
    
    return 0;
}

#ifndef EVALUATOR_H
#define EVALUATOR_H

#include "Parser.h"
#include "LinkedQueue.h"
#include "LinkedStack.h"
#include "RuntimeException.h"
#include <cmath>
#include <cctype>
#include <sstream>
#include <iostream>

class Evaluator {
public:
  // user-defined exceptions
    class DivisionByZeroException : public RuntimeException 
    {
    public:
        DivisionByZeroException() : RuntimeException("Division by zero") {}
    };     
private:
  /* declare member variables; 
    may include a string postfix queue and a double value stack */
    LinkedStack<double> valStack;
    Parser * parser;
  
  /* declare utility functions */
    double eval(double v1, double v2, Parser::EnumTokens token) throw (DivisionByZeroException); // eval for two numbers
    double eval(double v1, Parser::EnumTokens token); // if negative, negate
    bool isOperator(Parser::EnumTokens token); // is an operator

public:
    Evaluator(Parser * par): parser(par) {} // constructor
    double getValue(); // returns the result of expression evaluation
    bool testValid(); // run a test eval to make sure its good
    
};

#endif

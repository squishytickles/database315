#ifndef UTILITY_H
#define UTILITY_H

#include <string>
#include <vector>
#include <iostream>

void stringtok(std::vector<std::string> &v, std::string const &in, const char * const delim, bool includeDelim);

void readInfix(std::string& infix);

bool isNumerical(std::string toTest);

bool parenthesisBalanced(std::string infix);

#endif

#include "Evaluator.h"

using namespace std;

double Evaluator::eval(double v1, double v2, Parser::EnumTokens token) throw(DivisionByZeroException)
{
    // evaluate per order of operations
    switch (token)
    {
        case Parser::EXP:   return pow(v1,v2); break;
        case Parser::PLUS:  return v1 + v2; break;
        case Parser::MINUS: return v1 - v2; break;
        case Parser::MULT:  return v1 * v2; break;
        case Parser::DIV:
        {
            if (v2 == 0) throw DivisionByZeroException();
            else return v1 / v2;
            break;
        }
        default: return 0;

    }
    
    return 0;
}

double Evaluator::eval(double v1, Parser::EnumTokens token)
{
    if (token == Parser::UNARY_MINUS) return -v1;
    return 0;
}

bool Evaluator::isOperator(Parser::EnumTokens token)
{    
    switch (token)
    {
        case Parser::EXP:           return true; break;
        case Parser::PLUS:          return true; break;
        case Parser::MINUS:         return true; break;
        case Parser::MULT:          return true; break;
        case Parser::DIV:           return true; break;
        case Parser::UNARY_MINUS:   return true; break;
        default:                    return false;
    }
}

double Evaluator::getValue()
{
    /* returns the result of expression evaluation */

    Parser::EnumTokens token;
    double v1, v2;
    LinkedQueue<string>& postfix = parser -> postfix;
    
    while (!postfix.isEmpty())
    {
        // first get a token
        try 
        {
            token = parser -> getToken(postfix.dequeue());
        } 
        catch (...) {
            cerr << "Something is wrong with the postfix queue" << endl;
        }
        
        // if its an operator
        if (isOperator(token))
        {
            try 
            {
                // if its a negation, only worry about the prev term
                if (token == Parser::UNARY_MINUS)
                {
                    v1 = valStack.pop();
                    valStack.push(eval(v1,token));
                }
                // otherwise its an op for the prev two terms
                else
                {
                    v2 = valStack.pop();
                    v1 = valStack.pop();
                    valStack.push(eval(v1,v2,token));
                }
            } catch (DivisionByZeroException& e) 
            {
                cerr << e << endl;
                return 0;
            } catch (...) 
            {
                cerr << "Something is wrong with v1 or v2" << endl;
                return 0;
            }
        }
        // otherwise if its not an operator and not at the end its a val
        else if (token != Parser::END)
        {
            try
            {
                // if its already a numerical value
                if (isNumerical(parser -> curVal))
                {
                    istringstream ss;
                    double val;
                    
                    ss.str(parser -> curVal);
                    
                    ss >> val;
                    valStack.push(val);
                }
                else // if its a var, enter the value
                {
                    cout << parser -> curVal << " is not yet defined.  Please enter a value: ";
                    
                    double val;
                    
                    cin.ignore();
                    cin >> val;
                    valStack.push(val);
                }
            } 
            catch (...) 
            {
                cerr << "Wrong value: " << parser -> curVal << endl;
            }
        }
    }
    
    try {
        return valStack.pop();
    } catch (...) {
        cerr << "Is postfix empty?" << endl;
    }
    
    return 0;
}

bool Evaluator::testValid()
{
    /* returns the result of if expression evaluation is good */
    
    bool good = true;
    Parser::EnumTokens token;
    double v1, v2;
    LinkedQueue<string>& postfix = parser -> postfix;
    
    while (!postfix.isEmpty())
    {
        // first get a token
        try 
        {
            token = parser -> getToken(postfix.dequeue());
        } 
        catch (...) {
            good = false;
        }
        
        // if its an operator
        if (isOperator(token))
        {
            try 
            {
                // if its a negation, only worry about the prev term
                if (token == Parser::UNARY_MINUS)
                {
                    v1 = valStack.pop();
                    valStack.push(eval(v1,token));
                }
                // otherwise its an op for the prev two terms
                else
                {
                    v2 = valStack.pop();
                    v1 = valStack.pop();
                    valStack.push(eval(v1,v2,token));
                }
            } catch (DivisionByZeroException& e) 
            {
                cerr << e << endl;
                return 0;
            } catch (...) 
            {
                good = false;
                return 0;
            }
        }
        // otherwise if its not an operator and not at the end its a val
        else if (token != Parser::END)
        {
            try
            {
                // if its already a numerical value
                if (isNumerical(parser -> curVal))
                {
                    istringstream ss;
                    double val;
                    
                    ss.str(parser -> curVal);
                    
                    ss >> val;
                    valStack.push(val);
                }
                else // if its a var, enter the value
                {
                    
                    valStack.push(1);
                }
            } 
            catch (...) 
            {
                good = false;
            }
        }
    }
    
    try {
        return valStack.pop();
    } catch (...) {
        good = false;
    }
    
    return good;
}


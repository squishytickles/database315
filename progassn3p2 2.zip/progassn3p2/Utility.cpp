#include "Utility.h"
using namespace std;

void stringtok(vector<string> &v, string const &in,
               const char * const delim = " \t\n",
               bool includeDelim = false)
{
    const string::size_type len = in.length();
    string::size_type i;
    string::size_type j = 0;
    int k;
    
    while ( j < len )
    {
        // find the start of the token
        i = in.find_first_not_of(delim, j);
        
        if (i == string::npos) { // nothing left but delim
            if (includeDelim) {
                string s = in.substr(j);
                for (k = 0; k < s.length(); k++)
                    v.push_back(s.substr(k,1));
            }
            return;
        } else
            if (includeDelim)
                if (i-j!=0) {
                    string s = in.substr(j, i-j);
                    for (k = 0; k < s.length(); k++)
                        v.push_back(s.substr(k,1));
                }
        
        // find the end of the token
        j = in.find_first_of(delim, i);
        
        // push token
        if (j == string::npos) { // nothing left but a token
            v.push_back(in.substr(i));
            return;
        } else
            v.push_back(in.substr(i, j-i));
    }
}

void readInfix(string& infix)
{
    cout << "\tPlease enter an infix expression (using floating point values and or variables (no whitespace please): " << endl << "\t>> ";
    
    cin.ignore();
    getline(cin,infix);
    
    cout << endl;
}

bool isNumerical(string toTest) // test if its a var or a number
{
    for (int i = 0; i < toTest.length(); i ++)
    {
        if (toTest.substr(i,1) != "." && !isdigit(toTest[i]) && toTest.substr(i,1) != " ")
        {
            return false;
        }
    }
    
    return true;
}

bool parenthesisBalanced(std::string infix)
{
    int lC = 0, rC = 0;
    
    for (int i = 0; i < infix.length(); i ++)
    {
        if (infix.substr(i,1) == "(") lC++;
        if (infix.substr(i,1) == ")") rC++;
    }
    
    if (lC == rC) return true;
    else cout << lC << " " << rC << endl; return false;
}

#include "RuntimeException.h"
#include "Parser.h"
#include "Evaluator.h"
#include <iostream>

using namespace std;

int main()
{    
    bool done = false;
    int menuChoice = 0;
    
    string infix = "";
    string postfix = "";
    vector<string> tokens;
    
    while (!done)
    {
        for (int i = 0; i < 3; i ++) cout << endl; // make some space
        cout << "Assignment 3 Part 2 - Graham Leslie"   << endl;
        cout << " -- Practically Wolfram Alpha ;)"         << endl;
        cout << "-----------------------------------"   << endl;
        cout << "1. Enter an infix expression."         << endl;
        cout << "2. Check if parentheses are"           << endl
             << "   balanced."                          << endl;
        cout << "3. Check if infix is correct."         << endl;
        cout << "4. Convert infix to postfix."          << endl;
        cout << "5. Evaluate postfix with floats"       << endl;
        cout << "6. Display value of algebraic"         << endl
             << "   expression."                        << endl;
        cout << "7. Quit."                              << endl;
        cout << ">> ";
        
        cin >> menuChoice;
        
        switch (menuChoice)
        {
            case 1: // infix in
            {
                readInfix(infix);
                cout << "\tRead,\n\tInfix: " << infix << endl;
                break;
            }
            case 2: // check parentheses
            {
                string are = " ";
                
                if (!parenthesisBalanced(infix)) are = " not ";
                
                cout << "\tParenthesis" << are << "balanced." << endl;
                break;
            }
            case 3: // display if infix is correct (run a test eval)
            {
                Parser p(infix);
                p.toPostfix(false);
                Evaluator e(&p);
                bool good = e.testValid();
                
                string wasGood = " ";
                
                if (!good) wasGood = " not ";
                
                cout << "\tInfix was" << wasGood << "good." << endl;
                break;
            }
            case 4: // convert infix to postfix
            {
                Parser p(infix);
                
                bool trace = false;
                
                cout << "\tDo you wish to trace opStack and postfix? (0,1) ";
                cin >> trace;
                
                p.toPostfix(trace);
                cout << "\tPostfix: ";
                p.printPostfix();
                break;
            }
            case 5: // evaluate postfix with floats exp in
            {
                Parser p(infix);
                p.toPostfix(false);
                Evaluator e(&p);
                double r = e.getValue();
                cout << "\tEvauluted: " << r << endl;
                break;
            }
            case 6: // display value of algebraic expression
            {
                cout << "\tI'm not sure how 6 is different from 5, and nobody answered the question on Piaza, so I just had it do the same thing.  It shows the result of the algebraic expression solved." << endl;
                
                Parser p(infix);
                p.toPostfix(false);
                Evaluator e(&p);
                double r = e.getValue();
                cout << "\tEvaluted: " << r << endl;
                break;
            }
            case 7: return 0;   // quit
            default: cout << "Input not understood." << endl;
        }
    }
    
    
    return 0;  
}

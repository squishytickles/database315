#ifndef PARSER_H
#define PARSER_H

#include "LinkedStack.h"
#include "LinkedQueue.h"
#include "RuntimeException.h"
#include "Utility.h"
#include <string>
#include <stdlib.h>
#include <ctype.h>
#include <vector>
#include <iostream>

class Parser {
private:
  
    class Precedence        // for tokens
    {
    public:
        int input, stack;
        Precedence(int i = 0, int s = 0) : input(i), stack(s) { }
    };
    
public:

    
  /* declare constants */
    static const char* delimeters;
    vector<string> tokens;
    
    static const Precedence precTable[];
    static const char opTable[];
    
    enum EnumTokens {END,VALUE,LPAREN,RPAREN,EXP,MULT,DIV,PLUS,MINUS,UNARY_MINUS};
    
  /* declare member variables;
   may include a string postfix queue and a integer operator stack */
    
    LinkedStack<char> opStack;    // operator stack
    LinkedQueue<string> postfix;    // postfix queue
    
    string curVal;
  
  /* declare utility functions */
    
    EnumTokens getToken(string c, EnumTokens prevToken = VALUE);
    
//public:
    
  // constructor
    Parser(std::string s): opStack(), postfix()
    {
        //tokens = s.c_str();     // converts to a cstyle string
        stringtok(tokens, s, delimeters, true);
        tokens.push_back("\0");  // tell the parser to stop
        opStack.push(END);      // initializes opStack
    }
  
  // accessor method
    LinkedQueue<string> getPostfix() { return postfix; }
  
  // operations
    void printInfix();
    void printPostfix();
    void toPostfix(bool trace);
    string strPostfix();
};

#endif

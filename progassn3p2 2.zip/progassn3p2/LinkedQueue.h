#ifndef LINKEDQUEUE_H
#define LINKEDQUEUE_H

#include <iostream>
#include "RuntimeException.h"
#include "LinkedList.h"

template <typename T>
class LinkedQueue {
private:
   LinkedList<T> ll;

public:
   // user-defined exceptions
   class QueueEmptyException : public RuntimeException {
   public:
     QueueEmptyException() : RuntimeException("Access to an empty queue") {}
   };

   LinkedQueue() { } // constructor
    ~LinkedQueue() { ll.removeAll(); } // destructor
   LinkedQueue(const LinkedQueue<T>& queue) // copy constructor
    {
        ll.removeAll();
        ll = queue.ll;
    }
   LinkedQueue<T>& operator=(const LinkedQueue<T>& queue)
    {
        ll.removeAll();
        ll = queue.ll;
        return *this;
    }// assignment operator
   
   // query function
    int size() const { return ll.size(); }
    bool isEmpty() const {  return ll.isEmpty();  }
   
   // accessor function
   T first() const throw(QueueEmptyException)
    { 
        if (ll.isEmpty())
        {
            throw QueueEmptyException();
        }
        else
        {
            return ll.getHead()->getElem();
        }
    }
   
   // update functions
    void enqueue(T elem) { ll.insertLast(elem); }
   T dequeue() throw(QueueEmptyException)
    {
        if (ll.isEmpty())
        {
            throw QueueEmptyException();
        }
        else
        {
            return ll.removeFirst();
        }
        
        return 0;
    }
   
   friend ostream & operator<<(ostream& out,const LinkedQueue<T>& queue)
    {
        out << queue.ll;
        return out;
    }
};

#endif

//LinkedList.h

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "RuntimeException.h"

template <typename T>
class LinkedList;

template <typename T>
class ListNode {
private:
    T obj;
    ListNode<T> *next;
    friend class LinkedList<T>;
    
public:
    ListNode(T e = 0, ListNode<T> *n = NULL) : obj(e), next(n) { }
    T getElem() const { return obj; }
    ListNode<T> * getNext() const { return next; }
};

template <typename T>
class LinkedList {
private:
    ListNode<T> *head, *tail;
    
public:
    // user-defined exceptions
    class EmptyLinkedListException : public RuntimeException {
    public:
        EmptyLinkedListException() : RuntimeException("Empty linked list") {}
    };
    class InvalidPointerException : public RuntimeException {
    public:
        InvalidPointerException() : RuntimeException("Attempt to use null pointer") {}
    };   
    
    LinkedList() : head(NULL), tail(NULL) {} // default constructor
    
    ~LinkedList() // destructor
    {
        removeAll();
        delete head;
        delete tail;
    }
    
    LinkedList(const LinkedList& ll) { *this = ll; } // copy constructor
    
    LinkedList & operator=(const LinkedList & ll)
    {
        removeAll();
        
        ListNode<T> *current = ll.getHead(); // iterator starts at head
        
        while (current != NULL) // if its not at the end
        {
            insertFirst(current->getElem()); // add the node
            current = current->getNext(); // move iterator forward
        }
        
        return *this;
    }// assignment operator
    
    // query function
    int size() const
    {
        ListNode<T> *current = getHead(); // iterator starts at head
        int c = 0; // counter starts at 0
        
        while (current != NULL) // if its not at the end
        {
            c ++; // iterate
            current = current->getNext(); // move iterator forward
        }
        
        return c;
    }
    
    bool isEmpty() const { return (head == NULL); }
    
    // accessor functions
    T first() const throw(EmptyLinkedListException)
    {
        if (head == NULL) throw EmptyLinkedListException(); // if empty, exception
        else return head->getElem(); // otherwise return the head's value
        
        return 0;
    }
    
    ListNode<T> *getHead() const { return head; }
    ListNode<T> *getTail() const { return tail; }
    
    // update functions
    void insertFirst(T newobj)
    {
        ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
        if (isEmpty()) head = tail = newNode; // if its empty
        else
        {
            newNode->next = head; // after the new node is the current head
            head = newNode; // make the current head the new node
        }
    }
    
    T removeFirst() throw(EmptyLinkedListException)
    {
        if (head == NULL) throw EmptyLinkedListException(); // if empty, exception
        else
        {
            ListNode<T> *node = head; // create access to head
            head = node->next; // make head point to the next (new head)
            if (head == NULL) tail = NULL; // if its empty now, make it so
            T obj = node->obj; // for returning the object
            delete node; // delete the old node
            return obj; // return the object value of it
        }
        
        return 0;
    }
    
    void insertLast(T newobj)
    {
        ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
        if (isEmpty()) head = tail = newNode; // if its empty
        else // if not
        {
            tail->next = newNode; // after tail is the new node
            tail = newNode; // have tail point to the new node
        }
    }
    
    void insertAfter(T newobj, ListNode<T> *node) throw(InvalidPointerException)
    {
        ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
        if (head == NULL) throw EmptyLinkedListException(); // if empty
        
        ListNode<T> *current = getHead(); // iterator starts at head
        
        bool done = false;
        
        while (current != NULL && done == false) // if its not at the end
        {
            if (current == node)
            {
                if (current != tail)
                {
                    newNode->next = current->next;
                    current->next = newNode;
                    done = true;
                }
                else
                {
                    current->next = newNode;
                    tail = newNode;
                    done = true;
                }
            }
            
            current = current->getNext(); // move iterator forward
        }
        
        if (!done) throw EmptyLinkedListException();
        
    }
    
    T remove(ListNode<T> *node) throw(InvalidPointerException)
    {    
        if (head == NULL) throw EmptyLinkedListException(); // if empty
        if (node == NULL) throw EmptyLinkedListException(); // if passed in null
        
        ListNode<T> *current = getHead(); // iterator starts at head
        ListNode<T> *prev = NULL;
        
        if (node == head) // if its the head
        {
            head = node->next;
            T obj = node->obj; // for returning the object
            delete node;
            return obj;
        }
        
        while (current != NULL) // if its not at the end
        {
            if (current == node)
            {
                if (current == tail && current == node) // if its the tail
                {
                    T obj = node->obj; // for returning the object
                    tail = prev;
                    prev->next = NULL;
                    delete current;
                    return obj;
                }
                else // if its in the middle somewhere
                {
                    T obj = node->obj; // for returning the object
                    prev->next = node->next;
                    delete current;
                    return obj;
                }
            }
            
            prev = current; // keep track of the previous node
            current = current->getNext(); // move iterator forward
        }
        
        throw EmptyLinkedListException();
        return 0;
    }
    
    void removeAll()
    {
        ListNode<T> *current = getHead(); // iterator starts at head
        ListNode<T> *next = NULL; // next node
        
        while (current != NULL) // if its not at the end
        {
            next = current->getNext(); // get the next node
            delete current; // delete the current
            current = next; // move to the next
        }
        
        head = tail = NULL; // reset the head and tail
    }
    
    friend ostream& operator<< (ostream& out, const LinkedList<T>& ll)
    {
        ListNode<T> *current = ll.getHead(); // iterator starts at head
        
        while (current != NULL) // if its not at the end
        {
            out << current->getElem() << " "; // to ostream
            current = current->getNext(); // move iterator forward
        }
        
        return out;
    }//overload <<
};


#endif

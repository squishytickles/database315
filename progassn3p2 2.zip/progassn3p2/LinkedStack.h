// LinkedListStack.h

#ifndef LINKEDSTACK_H_
#define LINKEDSTACK_H_

#include <iostream>
#include "RuntimeException.h"
#include "LinkedList.h"

template <typename T>
class LinkedStack
{
private:
   LinkedList<T> ll;
public:
   // user-defined exceptions
   class StackEmptyException : public RuntimeException {
   public:
     StackEmptyException() : RuntimeException("Stack is empty") {}
   };
   
    LinkedStack() {  } // default constructor
    ~LinkedStack() { ll.removeAll(); } // destructor
    LinkedStack(const LinkedStack<T>& stack) // copy constructor
    {
        ll.removeAll();
        ll = stack.ll;
    }
    LinkedStack<T>& operator=(const LinkedStack<T>& stack)
    {
        ll.removeAll();
        ll = stack.ll;
    }// assignmnet operator
   
   // query functions
    bool isEmpty() { return ll.isEmpty(); }
    int size() const { return ll.size(); }
   
   // accessor function
    T top() const throw(StackEmptyException)
    {
        if (ll.isEmpty())
        {
            throw StackEmptyException();
        }
        else
        {
            return ll.getHead()->getElem();
        }
    }
   
   // update functions
    void push(const T elem) { ll.insertFirst(elem); }
    T pop() throw(StackEmptyException)
    {
        if (ll.isEmpty())
        {
            throw StackEmptyException();
        }
        else
        {
            return ll.removeFirst();
        }
    }
   
    friend ostream& operator<<(ostream& out,const LinkedStack<T>& stack)
    {
        out << stack.ll;
        return out;
    }
};


#endif

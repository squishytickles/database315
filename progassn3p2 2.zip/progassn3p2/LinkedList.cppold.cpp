//LinkedList.cpp

#include <iostream>
#include "LinkedList.h"
using namespace std;
// assignment operator

template class LinkedList<char>;
template class LinkedList<double>;
template class LinkedList<string>;

template <typename T>
LinkedList<T>& LinkedList<T>::operator=(const LinkedList<T>& ll) // worst case O(n)
{
    removeAll();
    
    ListNode<T> *current = ll.getHead(); // iterator starts at head
    
    while (current != NULL) // if its not at the end
    {
        insertFirst(current->getElem()); // add the node
        current = current->getNext(); // move iterator forward
    }
    
    return *this;
}

// query function

template <typename T>
int LinkedList<T>::size() const {
    ListNode<T> *current = getHead(); // iterator starts at head
    int c = 0; // counter starts at 0
    
    while (current != NULL) // if its not at the end
    {
        c ++; // iterate
        current = current->getNext(); // move iterator forward
    }
    
    return c;
}

// accessor function

template <typename T>
T LinkedList<T>::first() const throw(EmptyLinkedListException)
{
    if (head == NULL) throw EmptyLinkedListException(); // if empty, exception
    else return head->getElem(); // otherwise return the head's value
    
    return 0;
}

// update functions

template <typename T>
void LinkedList<T>::insertFirst(T newobj)
{
    ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
    if (isEmpty()) head = tail = newNode; // if its empty
    else
    {
        newNode->next = head; // after the new node is the current head
        head = newNode; // make the current head the new node
    }
}

template <typename T>
void LinkedList<T>::insertLast(T newobj)
{
    ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
    if (isEmpty()) head = tail = newNode; // if its empty
    else // if not
    {
        tail->next = newNode; // after tail is the new node
        tail = newNode; // have tail point to the new node
    }
}

template <typename T>
void LinkedList<T>::insertAfter(T newobj, ListNode<T> *node) // worst case O(n)
    throw(InvalidPointerException)
{
    ListNode<T> *newNode = new ListNode<T>(newobj); // reference the new node
    if (head == NULL) throw EmptyLinkedListException(); // if empty
    
    ListNode<T> *current = getHead(); // iterator starts at head
    
    bool done = false;
    
    while (current != NULL && done == false) // if its not at the end
    {
        if (current == node)
        {
            if (current != tail)
            {
                newNode->next = current->next;
                current->next = newNode;
                done = true;
            }
            else
            {
                current->next = newNode;
                tail = newNode;
                done = true;
            }
        }
        
        current = current->getNext(); // move iterator forward
    }
    
    if (!done) throw EmptyLinkedListException();
    
}

template <typename T>
T LinkedList<T>::removeFirst() throw(EmptyLinkedListException)
{
    if (head == NULL) throw EmptyLinkedListException(); // if empty, exception
    else
    {
        ListNode<T> *node = head; // create access to head
        head = node->next; // make head point to the next (new head)
        if (head == NULL) tail = NULL; // if its empty now, make it so
        T obj = node->obj; // for returning the object
        delete node; // delete the old node
        return obj; // return the object value of it
    }
    
    return 0;
}

template <typename T>
T LinkedList<T>::remove(ListNode<T> *node) // worst case O(n) (if tail), best case O(1) if head, or somewhere in between for anything else
    throw(InvalidPointerException)
{    
    if (head == NULL) throw EmptyLinkedListException(); // if empty
    if (node == NULL) throw EmptyLinkedListException(); // if passed in null
    
    ListNode<T> *current = getHead(); // iterator starts at head
    ListNode<T> *prev = NULL;
    
    if (node == head) // if its the head
    {
        head = node->next;
        T obj = node->obj; // for returning the object
        delete node;
        return obj;
    }
    
    while (current != NULL) // if its not at the end
    {
        if (current == node)
        {
            if (current == tail && current == node) // if its the tail
            {
                T obj = node->obj; // for returning the object
                tail = prev;
                prev->next = NULL;
                delete current;
                return obj;
            }
            else // if its in the middle somewhere
            {
                T obj = node->obj; // for returning the object
                prev->next = node->next;
                delete current;
                return obj;
            }
        }
        
        prev = current; // keep track of the previous node
        current = current->getNext(); // move iterator forward
    }
    
    throw EmptyLinkedListException();
    return 0;
}

template <typename T>
void LinkedList<T>::removeAll() // O(n)
{
    ListNode<T> *current = getHead(); // iterator starts at head
    ListNode<T> *next = NULL; // next node
    
    while (current != NULL) // if its not at the end
    {
        next = current->getNext(); // get the next node
        delete current; // delete the current
        current = next; // move to the next
    }
    
    head = tail = NULL; // reset the head and tail
}

// LinkedStack.cpp

#ifndef LINKEDLISTSTACK_CPP
#define LINKEDLISTSTACK_CPP

#include "LinkedStack.h"

// assignmnet operator

template <typename T>
LinkedStack<T>& LinkedStack<T>::operator=(const LinkedStack<T>& stack) 
{
    ll.removeAll();
    ll = stack.ll;
}

// query function

template <typename T>
T LinkedStack<T>::top() const throw(StackEmptyException)
{
    if (ll.isEmpty())
    {
        throw StackEmptyException();
    }
    else
    {
        return ll.getHead()->getElem();
    }
}

// update function

template <typename T>
T LinkedStack<T>::pop() throw(StackEmptyException)
{
    if (ll.isEmpty())
    {
        throw StackEmptyException();
    }
    else
    {
        return ll.removeFirst();
    }
}


#endif 
